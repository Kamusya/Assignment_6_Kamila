package com.company;

public class Singleton {

    public static void main(String[] args) {
        Database database = Database.getInstance();


    }
}
